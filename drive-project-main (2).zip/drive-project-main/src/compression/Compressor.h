#ifndef COMPRESSOR_H
#define COMPRESSOR_H

#include <string>

using namespace std;

string compress(string text);
string decompress(string text);

#endif